# -*- coding: utf-8 -*-
"""
===============================================================================
Generating a stimulus from a video
===============================================================================

*This example shows how to use videos as input stimuli for a retinal implant.*

Loading a video
----------------

A video can be loaded as follows:

.. code:: python

    stim = p2p.stimuli.videos.VideoStimulus("path-to-video.mp4")

There is an example video that is pre-installed with pulse2percept. You can
load it like this.

"""
# sphinx_gallery_thumbnail_number = 1

import pulse2percept as p2p
import numpy as np

video = p2p.stimuli.BostonTrain(as_gray=True)

print(video)

data = video.data.reshape(video.vid_shape)

import matplotlib.pyplot as plt
plt.imshow(data[..., 0], cmap='gray')

video.play()

edge_video = video.resize((100, 100)).filter('Sobel')
edge_video.play()

video.resize((40, 40)).rotate(10).invert().filter('median').play()


implant = p2p.implants.ArgusII()

implant.stim = video.resize(implant.shape)

model = p2p.models.AxonMapModel()
model.build()
percept = model.predict_percept(implant)
percept.play()

percept.save('video_percept.mp4')
