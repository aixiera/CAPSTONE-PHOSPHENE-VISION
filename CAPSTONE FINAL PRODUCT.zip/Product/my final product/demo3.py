from pulse2percept.implants.cortex import Neuralink
from pulse2percept.topography import NeuropythyMap
from pulse2percept.models.cortex import ScoreboardModel
import pulse2percept as p2p
import matplotlib.pyplot as plt

pict_link=['E:/Semi Study/CLC 12/Normal Pictures/first.jpg', 
           'E:/Semi Study/CLC 12/Normal Pictures/second.jpg',
           'E:/Semi Study/CLC 12/Normal Pictures/third.jpg',
           'E:/Semi Study/CLC 12/Normal Pictures/fourth.jpg']

for i in range(len(pict_link)):
    # Load image stimulus
    stim = p2p.stimuli.ImageStimulus(pict_link[i])
    stim = stim.rgb2gray().invert()  # optional preprocessing

    # Choose implant + model
    implant = p2p.implants.PRIMA()
    model = p2p.models.ScoreboardModel(xrange=(-7, 7), yrange=(-7, 7), xystep=0.1)
    model.build()

    # Map stimulus to implant electrodes
    implant.stim = stim.resize(implant.shape)

    # Predict percept
    percept = model.predict_percept(implant)

    # Show & save percept
    percept.plot()
    percept.save('E:/Semi Study/CLC 12/Phosphene Pictures/picture_'+str(i+1)+'_PRIMA_Axon.png')