from pulse2percept.implants.cortex import Neuralink
from pulse2percept.topography import NeuropythyMap
from pulse2percept.models.cortex import ScoreboardModel
import pulse2percept as p2p
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import os
import imageio
import cv2

video_link=['E:/Semi Study/CLC 12/Normal videos/flower sea - Trim.mp4']

input_video = video_link[0]
output_video = 'E:/Semi Study/CLC 12/Phosphene Videos/flower sea argusII.mp4'

implant = p2p.implants.ArgusII()
model = p2p.models.ScoreboardModel(xrange=(-7,7), yrange=(-7,7), xystep=0.1)
model.build()

stim = p2p.stimuli.VideoStimulus(input_video)
stim = stim.rgb2gray().invert()  # optional
stim = stim.resize(implant.shape)
implant.stim = stim

print(dir(stim))
print(stim.shape)

percept = model.predict_percept(implant)
frames = percept.frames 

n_frames, height, width = frames.shape 
fps = 20 

os.makedirs(os.path.dirname(output_video), exist_ok=True)
fourcc = cv2.VideoWriter_fourcc(*'XVID')  # or 'mp4v' for mp4
video_writer = cv2.VideoWriter(output_video, fourcc, fps, (width, height), isColor=False)

for idx in range(n_frames):
    frame = frames[idx]
    img = (frame * 255).astype(np.uint8)
    video_writer.write(img)

video_writer.release()
print("Saved prosthetic-vision video to:", output_video)